class destination {
	public final int cost;
	public final Node target;
	
	public destination(Node targetNode, int costVal) {
		cost = costVal;
		target = targetNode;

	}

}